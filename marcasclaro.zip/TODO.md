# TODO: Modificar controladores para devolver URLs completas de imágenes

- [x] Modificar src/controllers/banners.controller.js para devolver URLs completas en getBanners, createBanner y updateBanner
- [x] Modificar src/controllers/cities.controller.js para devolver URLs completas en getCities, getCityImages, createCity y updateCity
- [x] Modificar src/controllers/company.controller.js para devolver URLs completas en getCompanyIcon, createCompanyIcon y updateCompanyIcon
